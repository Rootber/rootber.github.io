export default [
  {
    files: ['_javascript/**/*.js']
  }
];
